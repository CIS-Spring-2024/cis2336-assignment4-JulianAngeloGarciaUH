const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const port = 3000;

// Middleware to parse URL-encoded bodies (as sent by HTML forms)
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files from the public directory
app.use(express.static(path.join(__dirname, 'public')));

// POST request handler to process the order form data
app.post('/submit-order', (req, res) => {
    const orderData = req.body;

    // Validate form data
    for (const key in orderData) {
        const quantity = parseInt(orderData[key]);
        if (isNaN(quantity) || quantity <= 0 || quantity > 10) {
            return res.status(400).send('Invalid quantity for ' + key + '. Please enter a number between 1 and 10.');
        }
    }

    // Calculate total amount
    let totalAmount = 0;
    for (const key in orderData) {
        totalAmount += parseFloat(orderData[key]);
    }

    // Redirect to the order confirmation page with the total amount
    res.redirect('/order-confirmation?totalAmount=' + totalAmount.toFixed(2));
});

// GET request handler to serve the order confirmation page
app.get('/order-confirmation', (req, res) => {
    const totalAmount = req.query.totalAmount;
    res.send(`<h1>Order Confirmation</h1><p>Total Amount: $${totalAmount}</p>`);
});

// Allow GET request to the /submit-order endpoint to serve the order form
app.get('/submit-order', (req, res) => {
    // Serve the order form HTML or redirect to the form page
    res.sendFile(path.join(__dirname, 'public', 'menu.html'));
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
