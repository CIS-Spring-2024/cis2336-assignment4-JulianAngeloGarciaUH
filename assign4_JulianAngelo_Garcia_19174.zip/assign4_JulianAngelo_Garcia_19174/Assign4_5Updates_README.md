# Project Setup
* Sugarland Cafeteria website which contains:
    * Home Menu
    * Menu w/ pictures & categories, also shopping cart functionality
    * About (Meet the Owners) - Owner biography with picture

# Update Assigment 4/5

## server.js
* takes care off the calculations instead of the total being calculated on the front end
* also displays total amount of added up items
* Has no trouble with inputs and calculations but had problems with output, specifically confirming that the order was made, could only get error 405 but it's receiving POST request

## order.js
* line 89 is where the assignment 4 code is also found, POST items to server then outputs error or no error

## files split between frontend and backend folders
* front end has all CSS, HTML, images, JS files
* back end has packages and server.js





# Update Assigment 3

## Style
* Style element has added on style modifiers for code related to assignment 3

## menu.html
* Within each new div menu item, i've added a new line (<input type>), with attributes such as the name, data-price, quantity, which are used in the order.js file to calculate totals and cost
* line 279-303 contain a new block of code pertaining to the total and list of items, acting as a "Cart" function seen on shopping sites, issue with styling through CSS so used in-line styling and works as wanted

## order.js
* commented out on most lines, is a new file pertaining to assignment 3


