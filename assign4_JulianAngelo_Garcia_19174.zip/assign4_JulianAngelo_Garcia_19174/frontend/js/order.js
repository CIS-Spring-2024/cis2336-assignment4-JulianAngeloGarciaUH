document.addEventListener("DOMContentLoaded", function() {
    const menuItems = document.querySelectorAll('.menu-item'); // selects menu items
    const orderList = document.querySelector('.order-list'); // selects order list container
    const totalElement = document.getElementById('total'); // selects total price element
    const submitOrderButton = document.getElementById('submit-order'); // selects the submit order button
/* added event listeners when html is completely loaded without waiting */

    let selectedItems = []; // array to store selected items

    // updates the order list based on selected items
    function updateOrderList() {
        orderList.innerHTML = '';
        let totalPrice = 0;
    
        menuItems.forEach(menuItem => {
            const quantity = parseInt(menuItem.querySelector('input[type="number"]').value); /* gets the quantity of food items */
            const price = parseFloat(menuItem.querySelector('input[type="number"]').getAttribute('data-price')); /* gets the price of the food item by using the 'data-price' attribute of the input element */
            const totalItemPrice = price * quantity; /* calculates the total */
    
            // if valid, add to roder list
            if (!isNaN(totalItemPrice)) {
                const li = document.createElement('li'); // create list item element
                li.textContent = `${menuItem.querySelector('h2').textContent.trim()} - Quantity: ${quantity} - Total: $${totalItemPrice.toFixed(2)}`; // set the text content of the list item
                orderList.appendChild(li); // append list item to order lsit
                totalPrice += totalItemPrice; // add total item price to total price
            }
        });
    
        totalElement.textContent = `$${totalPrice.toFixed(2)}`; // update total price with calculated price
    }

    // handles quantity changes
    function handleQuantityChange() {
        const menuItem = this.closest('.menu-item');
        const name = menuItem.querySelector('h2').textContent.trim();
        const price = parseFloat(menuItem.getAttribute('data-price'));
        const quantity = parseInt(this.value);

        if (isNaN(quantity) || quantity < 0) {
            alert(`Invalid quantity for ${name}. Please enter a number between 1 and 10.`);
            return;
        }

        // if quantity is 0, should remove the item from selected items array
        if (quantity === 0) {
            selectedItems = selectedItems.filter(item => item !== menuItem);
        } else if (!selectedItems.includes(menuItem)) {
            selectedItems.push(menuItem);
        }

        updateOrderList();
    }
    
    // add event listeners to quantity input elements for each menu item
    menuItems.forEach(menuItem => {
        const quantityInput = menuItem.querySelector('input[type="number"]');
        quantityInput.addEventListener('change', handleQuantityChange);
    });
    // event listener to order button
    submitOrderButton.addEventListener('click', function() {
        // filter invalid quantities
        const invalidItems = selectedItems.filter(item => parseInt(item.querySelector('input[type="number"]').value) <= 0 || parseInt(item.querySelector('input[type="number"]').value) > 10);
        // if invalid, show alert
        if (invalidItems.length > 0) {
            const invalidItemNames = invalidItems.map(item => item.querySelector('h2').textContent.trim()).join(', ');
            alert(`Please correct the quantities for the following items: ${invalidItemNames}`);
            return;
        }

        if (selectedItems.length === 0) {
            alert('Please select at least one item to place the order.');
            return;
        }

         // Confirm the order with the customer
         const confirmMessage = `Are you sure you want to place the order?\n\nItems:\n${selectedItems.map(item => `- ${item.querySelector('h2').textContent.trim()} (${parseInt(item.querySelector('input[type="number"]').value)})`).join('\n')}\n\nTotal Price: $${totalElement.textContent}`;
         if (confirm(confirmMessage)) {
            // Log the selected items with their quantities and total prices
             console.log('Order submitted:', selectedItems.map(item => ({
                name: item.querySelector('h2').textContent.trim(),
                quantity: parseInt(item.querySelector('input[type="number"]').value),
                 totalPrice: parseFloat(item.getAttribute('data-price')) * parseInt(item.querySelector('input[type="number"]').value)
             })));

            // Clear the selected items array and update the order list
             selectedItems = [];
             updateOrderList();
            
            // ASSIGNMENT 4/5
            
            // Prepares order data
            const orderData = selectedItems.map(item => ({
                name: item.querySelector('h2').textContent.trim(),
                quantity: parseInt(item.querySelector('input[type="number"]').value),
                totalPrice: parseFloat(item.getAttribute('data-price')) * parseInt(item.querySelector('input[type="number"]').value)
            }));

            // send order data to backend
            fetch('/submit-order', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(orderData)
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Failed to submit order');
                }
                return response.json();
            })
            .then(data => {
                // Handle successful response from backend
                console.log('Order submitted:', data);
                alert('Your order has been placed successfully!');
                // Optionally redirect to a confirmation page or clear the order list
                selectedItems = [];
                updateOrderList();
            })
            .catch(error => {
                // Handle error
                console.error('Error submitting order:', error.message);
                alert('Failed to place the order. Please try again later.');
            });
        }});
});
